global.pitchAngle = 0.0;
global.yawAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngleO = 0.0;

local ptAngle = context.ptAngle or 0
local ywAngle = context.ywAngle or 0

local ywAngle = (context.mainHand and yawAngle) or yawAngleO
local ptAngle = (context.mainHand and pitchAngle) or pitchAngleO

local bl = context.bl
local item = context.item
local matrices = context.matrices
local player = context.player
local mainHand = context.mainHand
local deltaTime = context.deltaTime
local mainHandSwingProgress = context.mainHandSwingProgress
local swingMHand = context.swingMHand
local swingOHand = context.swingOHand
local particles = context.particles
local swingProgress = context.swingProgress
local equipProgress = context.equipProgress
local mainHandSwitchEvent = context.mainHandSwitchEvent
local offHandSwitchEvent = context.offHandSwitchEvent
local foodcount = Easings:easeInQuart(context.mainHand and foodCount or foodCountO)

local ptAngle = context.ptAngle or 0
local ywAngle = context.ywAngle or 0

local ywAngle = (context.mainHand and yawAngle) or yawAngleO
local ptAngle = (context.mainHand and pitchAngle) or pitchAngleO
local hand = context.hand
local age = P:getAge(context.player)
local crackleTick = M:floor(age / 3)
local l = (bl and 1) or -1

if mainHand and I:isOf(item, Items:get("minecraft:totem_of_undying")) then
	M:scale(matrices, 1.2, 1.2, 1.2)
	M:moveX(matrices, 0.07)
	M:rotateX(matrices, -110)
	M:rotateZ(matrices, -210)
	M:rotateY(matrices, -5)
end

if not mainHand and I:isOf(item, Items:get("minecraft:totem_of_undying")) then
	M:scale(matrices, 1.2, 1.2, 1.2)
	M:moveX(matrices, -0.07)
	M:rotateX(matrices, -110)
	M:rotateZ(matrices, -150)
	M:rotateY(matrices, 5)
end
