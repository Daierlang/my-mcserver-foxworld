//     _________      __        __     ___       __     __________      ________        ______        __           
//    /  _____  \    |  |      |  |   |   \     |  |   |   _____  \    |__    __|      /  __  \      |  |          
//   /  /     \__\   |  |      |  |   |    \    |  |   |  |     \  \      |  |        /  /  \  \     |  |          
//  |  |             |  |      |  |   |  |  \   |  |   |  |      |  |     |  |       /  /    \  \    |  |          
//   \  \______      |  |      |  |   |  |\  \  |  |   |  |      |  |     |  |      |  |______|  |   |  |          
//    \______  \     |  |      |  |   |  | \  \ |  |   |  |      |  |     |  |      |   ______   |   |  |          
//           \  \    |  |      |  |   |  |  \  \|  |   |  |      |  |     |  |      |  |      |  |   |  |          
//  ___       |  |   |  |      |  |   |  |   \  |  |   |  |      |  |     |  |      |  |      |  |   |  |          
//  \  \_____/  /     \  \____/  /    |  |    \    |   |  |_____/  /    __|  |__    |  |      |  |   |  |_________ 
//   \_________/       \________/     |__|     \___|   |__________/    |________|   |__|      |__|   |____________|
//
//  General Public License v3.0. Copyright (C) 2026 GeForceLegend.
//  https://github.com/GeForceLegend/Sundial-Lite
//  https://www.gnu.org/licenses/gpl-3.0.en.html
//
//  Gbuffer for armor glint, damaged block and sky textured
//

layout(location = 0) out vec4 gbufferData0;
layout(location = 1) out vec4 gbufferData3;

in vec4 color;
in vec2 texcoord;

#include "/libs/Uniform.glsl"

void main() {
    vec4 albedo = color * texture(gtexture, texcoord);
    #ifdef COLORWHEEL
        float ao;
        vec2 lightmap;
        vec4 overlayColor;
        clrwl_computeFragment(albedo, albedo, lightmap, ao, overlayColor);
        albedo.rgb = mix(albedo.rgb, overlayColor.rgb, overlayColor.a);
    #endif
    #ifdef DAMAGED_BLOCK
        albedo.rgb = log(3.0 * albedo.rgb + 1.0) / 3.0;
    #endif
    if (albedo.w < alphaTestRef) discard;
    #if MC_VERSION > 12111
    gbufferData3.rgb = pow(albedo.rgb, vec3(2.2));
    gbufferData3.a = 1.0;
    #else
    gbufferData0 = albedo;
    #endif
}

/* DRAWBUFFERS:03 */
